# Synchronous-FIFO
Designed a 16-depth Synchronous FIFO with 8-bit data input/output, including full/empty status tracking, simulated
successfully, with precise data management using sequential logic on rising
clock edges.
